package sabadoclase4;

import java.util.Scanner;

public class Login {

    public static void main(String[] args) {
        String black = "\033[30m";
        String red = "\033[31m";
        String green = "\033[32m";
        String yellow = "\033[33m";
        String blue = "\033[34m";
        String purple = "\033[35m";
        String cyan = "\033[36m";
        String white = "\033[37m";
        String reset = "\u001B[0m";

        String[] usuarios = {"Juan", "Maria", "Jose", "Ana"};
        String[] claves =   {"123",  "321",   "abc",  "111"};

        System.out.print(green);
        System.out.println("****************************************");
        System.out.println("*       B I E N V E N I D O S ! !      *");
        System.out.println("****************************************");
        System.out.println();
        System.out.print(blue);
        System.out.print("Ingrese su nombre de Usuario: ");
        String user = new Scanner(System.in).next();
        System.out.println();
        System.out.print("Ingrese su clave: ");
        String pass = new Scanner(System.in).next();
        System.out.println();
        System.out.print(reset);

        //System.out.println(user+" "+pass);
        //System.out.println(user=="root");
        //System.out.println(user.equals("root"));
        //Los Strings se comparan con el método equals!!
        
        boolean existe=false;
        int donde=0;
        
        for(int a=0;a<usuarios.length;a++){
            if(user.equals(usuarios[a])){
                existe=true;
                donde=a;
                break;
            }
        }
        
        //System.out.println(existe+" "+donde);
        
//        if(existe){
//            if(pass.equals(claves[donde])){
//                System.out.println(yellow+"Bienvenido "+user+"!"+reset);
//            }else{
//                System.out.println(red+"Clave Incorrecta!"+reset);
//            }
//        } else {
//            System.out.println(red+"Usuario Incorrecto!"+reset);
//        }

        if(existe && pass.equals(claves[donde]))    System.out.println(yellow+"Bienvenido "+user+"!"+reset);
        if(existe && !pass.equals(claves[donde]))   System.out.println(red+"Clave Incorrecta!"+reset);
        if(!existe)                                 System.out.println(red+"Usuario Incorrecto!"+reset);
        
        
    }
}
