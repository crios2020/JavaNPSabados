package sabadoclase4;

import java.time.LocalDate;
import java.util.Arrays;

public class SabadoClase4 {

    public static void main(String[] args) {
        // Clase04
        
        //Vectores - Arrays 
        
        //declaración de vectores
        int[] numeros = new int[4];
        String[] nombres = new String[4];
        
        //carga de valores
        numeros[0]=1;
        nombres[0]="Ana";
        numeros[1]=2;
        nombres[1]="Juan";
        numeros[2]=3;
        nombres[2]="Laura";
        numeros[3]=4;
        nombres[3]="Jose";
        
        //Error fuera de rango
        //numeros[4]=5;
        //nombres[4]="Mirta";
        
        //numeros[-1]=0;
        //nombres[-1]="Karina";
        
        
        /*
            numeros         nombres             indices
                1           Ana                     0
                2           Juan                    1
                3           Laura                   2
                4           Jose                    3
        */
        
        //sobrescribir la posición indice 2
        nombres[2]="Javier";
        
        //recuperamos una posición de los vectores
        System.out.println(numeros[2]+" "+nombres[2]);
        
        //Recorrido del vector
        System.out.println("****************************************************");
        for(int a=0;a<4;a++){
            System.out.println(numeros[a]+" "+nombres[a]);
        }
        
        //Método length
        System.out.println("Longitud del vector: "+numeros.length);
        System.out.println("****************************************************");
        for(int a=0;a<numeros.length;a++){
            System.out.println(numeros[a]+" "+nombres[a]);
        }
        
        //Recorrido usando while
        System.out.println("****************************************************");
        int b=0;
        while(b<numeros.length){
            System.out.println(numeros[b]+" "+nombres[b]);
            b++;
        }
        
        //Recorrido inverso
        System.out.println("****************************************************");
        for(int a=numeros.length-1;a>=0;a--){
            System.out.println(numeros[a]+" "+nombres[a]);
        }
        
        //Definición abreviada
        int[] vector={23,26,29,39,38,10,14,31,22,65};
        System.out.println("Longitud vector: "+vector.length);
        
        String[] semana={"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"};
        String[] meses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
        
        String fecha="2021-09-04";
        LocalDate ld=LocalDate.now();
	int diaSem=ld.getDayOfWeek().getValue(); // (1...7)  1- lunes .... 7- domingo
        int numMes=ld.getMonthValue();           // (1...12) 1- enero .... 12- diciembre
        int dia=ld.getDayOfMonth();
        int año=ld.getYear();
        
        System.out.println(ld);
        System.out.println("Hoy es "+semana[diaSem-1]+" "+dia+" de "+meses[numMes-1]+" de "+año);
        
        //Recorrido vector
        System.out.println("Longitud vector: "+vector.length);
        for(int a=0;a<vector.length;a++) System.out.print(vector[a]+" ");
        System.out.println();
        
        //Totalizar un vector numerico
        //Promediar un vector numerico
        int total=0;
        for(int a=0;a<vector.length;a++){
            total+=vector[a];
        }
        System.out.println("Total: "+total);
        System.out.println("Promedio: "+((double)total/vector.length));
        
        
        //int[] vector={23,26,29,39,38,10,14,31,22,65};
        //Buscar valor máximo y valor mínimo en vector
        vector[4]=77;
        vector[6]=8;
        vector[7]=11;
        int max=vector[0], min=vector[0];
        
        for(int a=1;a<vector.length;a++){
            if(max<vector[a]) max=vector[a];
            if(min>vector[a]) min=vector[a];
        }
        
        System.out.println("Valor máximo: "+max);
        System.out.println("Valor mínimo: "+min);
        
        //Operador resto %
        System.out.println(15%2);       // 1
        System.out.println(14%2);       // 0
        System.out.println(-14%2);      // 0
        System.out.println(-15%2);      //-1
        
        //Contar cantidad de números pares.
        //Contar cantidad de números impares.
        //Contar cantidad de número 10;
        int contPares=0, contImpares=0, cont10=0;
        for(int a=0;a<vector.length;a++){
            if(vector[a]%2==0) contPares++;
            else contImpares++;
            if(vector[a]==10) cont10++;
        }
        System.out.println("Cantidad números pares: "+contPares);
        System.out.println("Cantidad números impares: "+contImpares);
        System.out.println("Cantidad 10: "+cont10);
         
        
        //Copiar vectores
        int[] pares={2,4,6,8,10};
        int[] impares= new int[pares.length];
        int[] pares2=new int[pares.length];
        
        /*
            pares           impares             pares2
                2            _1_                 ___
                4            _3_                 ___
                6            _5_                 ___
                8            _7_                 ___
               10            _9_                 ___

        */
        
        for(int a=0;a<pares.length;a++){
            impares[a]=pares[a]-1;
        }
        
        for(int a=0;a<pares.length;a++){
            System.out.println(impares[a]+"\t"+pares[a]);
        }
        
        //Función System.arraycopy()
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        
        for(int a=0;a<pares.length;a++){
            System.out.println(pares[a]+"\t"+pares2[a]);
        }
        
        //Ordenar un vector
        for(int a=0;a<vector.length;a++) System.out.print(vector[a]+" ");
        System.out.println();
        
        Arrays.sort(vector);
        
        for(int a=0;a<vector.length;a++) System.out.print(vector[a]+" ");
        System.out.println();
        
        for(int a=vector.length-1; a>=0; a--) System.out.print(vector[a]+" ");
        System.out.println();
        
        System.out.println("Hoy es Sábado!!");
        
    }
    
}
