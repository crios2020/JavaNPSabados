public class Hola{
	public static void main(String[] args){
		System.out.println("Hola Mundo!!");
		System.out.println("Longitud Vector args: "+args.length);
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}
}
