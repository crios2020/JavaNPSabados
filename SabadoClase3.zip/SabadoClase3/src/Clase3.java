import java.text.DecimalFormat;

public class Clase3 {

	public static void main(String[] args) {
		// Estructuras de Repetición

		// Estructura While
		int a = 1;
		System.out.println("-- Inicio Estructura While --");
		while (a <= 10) {
			System.out.println(a);
			a++; // a=a+1;
		}
		System.out.println("-- Fin de Estructura While --");
		System.out.println(a);

		// Estructura do While
		a = 1;
		System.out.println("-- Inicio Estructura Do While --");
		do {
			System.out.println(a);
			a++;
		} while (a <= 10);
		System.out.println("-- Fin de Estructura Do While --");
		System.out.println(a);

		a = 10;
		while (a >= -10) {
			System.out.println(a);
			a -= 2;
		}

		// Modo de llaves Microsoft
		a = 1;
		while (a <= 10) {
			System.out.println(a);
			a++;
		}

		// Modo de llaves abreviado
		a = 1;
		while (a <= 10)
			System.out.println(a++);

		// loop infinito
//		a=1;
//		while(true) {
//			System.out.println(a);
//			a++;
//		}

//		a=1;
//		while(a<=10 || true) {
//			System.out.println(a);
//			a++;
//		}

//		a=1;
//		while(a<=10 || a>=10) {
//			System.out.println(a);
//			a++;
//		}

//		a=1;
//		while(a<=10);
//		{
//			System.out.println(a);
//			a++;
//		}
		
//		a=1;
//		while(a<=10);
//		{
//			System.out.println(a--);
//			a++;
//		}

		// Estructura While
		a = 1;
		System.out.println("-- Inicio Estructura While --");
		while (a <= 10) {
			System.out.println(a);
			a++; // a=a+1;
		}

		// Estructura for
		System.out.println("-- Inicio Estructura For --");
		for (int x = 1; x <= 10; x++) {

			System.out.println(x);
		}
		System.out.println("-- Fin Estructura For --");
		// System.out.println(x); //error la variable x esta fuera de scope(alcance)

		// recorrido con variable local
		for (a = 1; a <= 10; a++) {
			System.out.println(a);
		}
		System.out.println("-------------------------------------------");
		System.out.println(a);
		System.out.println("-------------------------------------------");
		for (a++; a <= 20; a++) {
			System.out.println(a);
		}
		System.out.println("-------------------------------------------");
		for (; a <= 30; a++) {
			System.out.println(a);
		}

		// Modo De llaves microsoft
		for (int x = 1; x <= 10; x++) {
			System.out.println(x);
		}

		// Modo de llaves abreviado
		for (int x = 1; x <= 10; x++)
			System.out.println(x);

		// omisión de parametros
		a = 1;
		for (;;) {
			System.out.println(a);
			if (a == 10)
				break; // rompe el ciclo
			a++;
		}

		// break continue
		// break rompe el ciclo
		// continue vuelve a evaluar la expresión
		for (int x = 1; x <= 20; x++) {
			if (x == 2 || x == 5)
				continue;
			System.out.println(x);
			if (x == 10)
				break;
		}
		for (int x = 1; x <= 10; x++) {
			if (x != 2 && x != 5)
				System.out.println(x);
		}

		// multiples variables de control
		for (int r = 1, s = 1; r <= 5 || s <= 10; r++, s++) {
			System.out.println(r + " " + s);
		}

		for (int r = 1, s = 1; r <= 5 && s <= 10; r++, s++) {
			System.out.println(r + " " + s);
		}

		// for anidado
		int cont = 0;
		for (int r = 1; r <= 10; r++) {
			for (int s = 1; s <= 10; s++) {
				for (int t = 1; t <= 10; t++) {
					cont++;
					System.out.println(r + " " + s + " " + t);
				}
			}
		}
		System.out.println(cont);
		DecimalFormat df=new DecimalFormat("00");
		for(int hora=0;hora<24;hora++) {
			for(int minuto=0;minuto<60;minuto++) {
				for(int segundo=0;segundo<60;segundo++) {
					System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
					//try { Thread.sleep(1000); } catch(Exception e) {}
				}
			}
		}
		
		
		//		5:5:5		05:05:05
		
		
		
		DecimalFormat precio=new DecimalFormat("###,###,###.00");
		double p1=2000000.50;
		System.out.println(p1);
		System.out.println(precio.format(p1));

		// loop infinito
		//for(;;);
		
		//for(int x=1; ; x++) {
		//	System.out.println(x);
		//}
		
		//for(int x=1; true; x++) {
		//	System.out.println(x);
		//}

		//for(int x=1; x<=10 || true; x++) {
		//	System.out.println(x);
		//}
		
		//for(int x=1; x<=10 || x>=1; x++) {
		//	System.out.println(x);
		//}
		//a=2;
		//for(int x=a;a<=10;x++) {
		//	System.out.println(x);
		//}
		
		//a=2;
		//for(int x=a;x<=10;a++) {
		//	System.out.println(x);
		//}
		
	}

}
