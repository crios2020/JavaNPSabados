import java.text.DecimalFormat;

public class Clase1 {

	public static void main(String[] args) {
		
		/*
		 * Curso: Java para no programadores 15hs.
		 * Días: Sábados	15:00 a 18:00 hs
		 * Profe: Carlos Ríos			carlos.rios@educacionit.com
		 * Materiales:	alumni.educacionit.com
		 * 				user: email
		 * 				pass: dni
		 * Github: https://github.com/crios2020/JavaNPSabados
		 * 
		 * Software:	JDK 11 o sup	IDE	Eclipse para java Web y Netbeans IDE
		 * 
		 * JDK: Java Development Kit (Kit de Desarrollo Java)
		 * 
		 * IDE: Integrated Development Enviroment	(Entorno de Desarrollo integrado)
		 * 
		 */
		
		// comentarios de una sola linéa
		
		/* Bloque de comentarios */
		
		System.out.println("Hola Mundo!");	//Imprime en consola

		//Lenguaje case sensitive
		// ; es el terminador y separador de sentencias
		
		// syso - ctrol - Enter: atajo para System.out.println(); en eclipse
		// sout - TAB: atajo para System.out.println(); en netbeans
		
		System.out.println("Hoy es Sábado!");
		
		System.out.print("1");				//imprime y mantiene el cursor en la misma linea
		System.out.print("2");
		System.out.print("3");
		System.out.println("4");
		System.out.println("EducaciónIT");
		
		/*
		 * 		Hola Mundo!
		 * 		Hoy es Sábado!
		 * 		1234
		 * 		EducaciónIT
		 * 		
		 */
		
		//Variables y Tipo de datos
		// Java es un lenguaje de tipado fuerte!
		
		//Tipo de datos entero
		int a;						//declaro la variable a
		a=2;						//asigno valor a la variable a
		
		int b=4;					//declaro y asigno valor a la variable
		
		int c=a+b;					//6
		
		int d=4, e=27, f=29, g=39;	//Declaración y asignación multiple de variables.
		
		//Las variables solo se pueden declarar una vez, pero pueden tener infinitas asignaciones
		//int a;			//error
		a=23;
		a=38;
		System.out.println(a);
		System.out.println(c);
		
		//Tipo de String
		String r="Recreo";
		String j="Cafe";
		
		System.out.println(r+j);			//RecreoCafe
		System.out.println(r+" "+j); 		//Recreo Cafe
		System.out.println(r+" y "+j); 		//Recreo y Cafe
		System.out.println(a+b); 			//42
		System.out.println("a+b="+a+b); 	//a+b=384
		System.out.println("a+b="+(a+b));	//a+b=42
		
		//tipo de datos char
		char car=65;
		System.out.println(car);
		car='c';
		System.out.println(car);
		
		//tipo de datos float 32 bits
		float fl=9.56f;
		System.out.println(fl);
		
		//tipo de datos double 64 bits
		double dl=9.56;
		System.out.println(dl);
		
		fl=100;
		dl=100;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=10;
		dl=10;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//Separador de Miles
		DecimalFormat df=new DecimalFormat("###,###,###.00");
		double precio=3000000.50;
		System.out.println(df.format(precio));
		
		//Tipo de datos boolean
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		
		//Operador de asignación =
		int nro1=5;
		int nro2=7;
		
		System.out.println(nro1+" "+nro2);
		
		nro1=nro2;
		// <---
		
		System.out.println(nro1+" "+nro2);
		
		//Operadores incrementales
		
		//sumar 1 a la variable	++
		nro1 ++;				//nro1=nro1+1;
		System.out.println(nro1);
		
		//restar 1 a la variable --
		nro1 --;				//nro1=nro1-1;
		System.out.println(nro1);
		
		//sumar x a la variable +=
		nro1 += 5;			//nro1=nro1+5;
		System.out.println(nro1);
		
		//restar x a la variable -=
		nro1 -= 5;			//nro1=nro1-5;
		System.out.println(nro1);
		
		//multiplicar *=
		nro1*=5;			//nro1=nro1*5;
		System.out.println(nro1);
		
		//dividir /=
		nro1/=5;			//nro1=nro1/5;
		System.out.println(nro1);
		
		//Constantes
		//Las constantes pertenecen a un tipo de datos, y solo pueden tener una asignación de valor.
		final double PI=3.14;
		//PI++;		//error
		
		/*
		 * Operadores Logicos
		 * 
		 * Operador				Nombre
		 * 	==					comparación (equals)
		 * 	< <= > >=			relacionales
		 *  !=					no igual (not equals)
		 *  !					no (not)
		 *  &&					and 			(shift 6)
		 *  ||					or				(altgr 1)
		 *  
		 */
		
		nro1=7;
		nro2=10;
		boolean log1=true;
		boolean log2=false;
		boolean log3=nro1==7;
		
		System.out.println(nro1==7); 				// true
		System.out.println(nro1==nro2);				// false
		System.out.println(nro1==nro1-1); 			// false
		
		System.out.println(nro1!=7); 				// false
		System.out.println(nro1!=nro2); 			// true
		
		System.out.println(nro1<10); 				// true
		System.out.println(nro1<=7); 				// true
		System.out.println(nro1<7); 				// false
		
		System.out.println(log1);					//true
		System.out.println(!log1);					//false
		System.out.println(!!log1);					//true
		System.out.println(!!!log1);				//false
		System.out.println(!!!!log1);				//true
		
		System.out.println(log3); 					//true
		
		/*
		 * 		Tablas de Verdad
		 * 
		 * 		X		Y	  			OR				AND
		 * 		F		F				F				F
		 * 		F		V				V				F
		 * 		V		F				V				F
		 * 		V		V				V				V
		 * 
		 */
		
		System.out.println(log1 || log2); 				//true			
		System.out.println(log1 && log2); 				//false
		
		// trabajar más expresiones booleanas
		
	}

}
