import java.util.Scanner;
public class Login {

	public static void main(String[] args){
		
		String black="\033[30m"; 
		String red="\033[31m"; 
		String green="\033[32m"; 
		String yellow="\033[33m"; 
		String blue="\033[34m"; 
		String purple="\033[35m"; 
		String cyan="\033[36m"; 
		String white="\033[37m"; 
		String reset="\u001B[0m";
		
		// Programa Login
		// user: root  	pass: 123
		System.out.print(green);
		System.out.println("****************************************");
		System.out.println("*       B I E N V E N I D O S ! !      *");
		System.out.println("****************************************");
		System.out.println();
		System.out.print(blue);
		System.out.print("Ingrese su nombre de Usuario: ");
		String user=new Scanner(System.in).next();
		System.out.println();
		System.out.print("Ingrese su clave: ");
		String pass=new Scanner(System.in).next();
		System.out.println();
		System.out.print(reset);
		
		//System.out.println(user+" "+pass);
		//System.out.println(user=="root");
		//System.out.println(user.equals("root"));
		//Los Strings se comparan con el método equals!!
		
		
		//if(user.equals("root")){
		//	if(pass.equals("123")){
		//		System.out.println(yellow+"Bienvenido "+user+"!"+reset);
		//	}else{
		//		System.out.println(red+"Clave Incorrecta!"+reset);
		//	}
		//}else{
		//	System.out.println(red+"Usuario Incorrecto!"+reset);
		//}

		if(user.equals("root") && pass.equals("123")) 	System.out.println(yellow+"Bienvenido "+user+"!"+reset);
		if(user.equals("root") && !pass.equals("123"))	System.out.println(red+"Clave Incorrecta!"+reset);
		if(!user.equals("root")) 						System.out.println(red+"Usuario Incorrecto!"+reset);

	}

}
