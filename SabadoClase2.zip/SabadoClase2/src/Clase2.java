import java.time.LocalDate;

public class Clase2 {

	public static void main(String[] args) {
		// Clase 02

		int nro1 = 5;
		int nro2 = 7;
		boolean log1 = true;
		boolean log2 = false;

		// operadores logicos and && or ||

		System.out.println(log1 || log2);

		// operadores binarios and & or |
		System.out.println(log1 | log2);

		System.out.println(log1 || (nro1 + 2 == nro2 && !log2));

		System.out.println(log1 | (nro1 + 2 == nro2 && !log2));

		System.out.println(log2 && (nro1 + 2 == nro2 && !log2));

		System.out.println(log2 & (nro1 + 2 == nro2 && !log2));

		System.out.println(true || true);
		System.out.println(true | true);

		System.out.println(false || false);
		System.out.println(false | false);

		System.out.println(false != false);
		System.out.println(false != true);
		System.out.println(true != false);
		System.out.println(true != true);

		System.out.println(!log1 || !!log2 || nro2 != 7 || nro2 + 18 != 25 || (!!log1 && !log1 && nro1 + 2 == nro2));

		int cont = 0;
		if (!log2)									cont++;
		if (!!log1)									cont++;
		if (nro1 != 7)								cont++;
		if (nro2 + 18 != 25)						cont++;
		if (!!log1 && !log1 && nro1 + 2 == nro2)	cont++;

		if (cont >= 3) 	System.out.println(true);
		else 			System.out.println(false);

		// Estructura condicional IF
		if (nro2 == 7) {
			System.out.println("verdad 1");
		}

		if (log1) {
			// indentación o código indentado
			System.out.println("verdad 2");
			System.out.println("java SE");
		}

		// Uso de llaves
		// Modo Microsoft
		if (!log1) {
			System.out.println("verdad 3");
		}

		// Modo Abreviado
		if (log1)
			System.out.println("verdad 4");

		
		// Estructura If Else
		if (!log1) {
			System.out.println("Verdad 5");
		} else {
			System.out.println("False 5");
		}
		
		//Uso de Llaves modo Microsoft
		if(log1)
		{
			System.out.println("Verdad 6");
		} 
		else 
		{
			System.out.println("False 6");
		}
		
		//Modo Abreviado
		if(log1) 	System.out.println("Verdad 7");
		else 		System.out.println("Falso 7");
		
		
		
		// Operador Ternario ?
		System.out.println((!log1)?"Verdad 8":"False 8");
		
		// Estructura switch
		LocalDate ld=LocalDate.now();
		int diaSem=ld.getDayOfWeek().getValue();
		System.out.println(diaSem);
		//diaSem=4;
		
		/*
		if(diaSem==1) System.out.println("Lunes");
		if(diaSem==2) System.out.println("Martes");
		if(diaSem==3) System.out.println("Miércoles");
		if(diaSem==4) System.out.println("Jueves");
		if(diaSem==5) System.out.println("Viernes");
		if(diaSem==6) System.out.println("Sábado");
		if(diaSem==7) System.out.println("Domingo");
		*/
		//diaSem=12;
		switch(diaSem) {
			case 1: 
				System.out.println("Lunes"); 		
				System.out.println("Inicio de Semana");
				break;
			case 2: System.out.println("Martes"); 		break;
			case 3: System.out.println("Miércoles"); 	break;
			case 4: System.out.println("Jueves"); 		break;
			case 5: System.out.println("Viernes"); 		break;
			case 6: System.out.println("Sábado"); 		break;
			case 7: System.out.println("Domingo"); 		break;
			default: System.out.println("Error!");
		}
		//diaSem=3;
		switch(diaSem) {
			case 1: case 2: case 3: case 4: case 5:
				System.out.println("Dia Laboral!");
				break;
			case 6: case 7:
				System.out.println("Fin de semana!");
				break;
			default: System.out.println("Error!");	
		}
		
		int numMes=ld.getMonthValue();
		
	}

}
