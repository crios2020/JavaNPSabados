package sabadoclase5;

public class SabadoClase5 {

    public static void main(String[] args) {
        // Clase 05 Interface Gráfica (GUI)
        
        /*
            Interface Gráfica AWT (Abstract Windows Type) :
                - Es la primer GUI.
                - Se encuentra dentro del nucleo de JAVA.
                - Es la más veloz.
                - No garantiza la misma apariencia en todos los SOs.
        
            Interface Gráfica Swing:
                - Se encuentra dentro del nucleo de JAVA.
                - Garantiza la misma apariencia en todos los SOs.
        
            Interface Gráfica JavaFX:
                - Cumple con el patron MVC.
                - Cross Platform (Desktop, Mobile, WebApp)
                - Libre (Open) https://openjfx.io/
                - Aparecio en Java 6
                - Fracaso Comercial (Se saco del JDK 11 0 sup).
        
        */
        
        //Hola.main(null);
        Gestion.main(null);
        //Calculadora.main(null);
        
    }
    
}
